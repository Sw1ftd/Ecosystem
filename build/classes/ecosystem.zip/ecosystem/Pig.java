/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecosystem;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author 807514
 */
public class Pig extends Animal{
    private ImageIcon ii;
    private Image img;
    public static double numPigs;
    
    public Pig(){
        super();
        super.typeOfAnimal = "Pig";
        if(numPigs < 500){
            numPigs++;
        }
        this.ii = new ImageIcon(getClass().getResource("/images/Pig.png"));
        this.img = ii.getImage();
    }
    @Override
    public void update(){
        age += .01;
        if(age >= 22){
            die();
        }
        move();
    }
    @Override
    public void draw(Graphics g){
        g.drawImage(img, x, y, 25, 25, null);
    }
    public static void eaten(){
        numPigs -= .006;
        //System.out.println(numPigs);
    }
    public static double getNumPigs() {
        return numPigs;
    }
}
