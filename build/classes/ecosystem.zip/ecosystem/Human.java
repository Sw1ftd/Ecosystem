/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecosystem;


/**
 *
 * @author 807514
 */
public abstract class Human extends Living{
    
    protected int life;
    protected int food;
    protected int water;
    protected double age;
    protected int intelligence;
    protected int strength;
    protected int stamina;
    protected String gender;
    protected boolean alive;
    
    public Human (){
        this.life = 100;
        this.food = 100;
        this.water = 100;
        this.age = 0;
        this.intelligence = 1;
        this.strength = 1;
        this.stamina = 1;
        this.alive = true;
        super.x = (int) (Math.random() * 1100);
        super.y = (int) (Math.random() * 800);
    }
    
    @Override
    public void update() {
        if(alive == true){
            food -= (int)(Math.random() * 5) + 5;
            water -= (int)(Math.random() * 10) + 10;
            age += .0001;
            if(life <= 0){
                die();
            }
            if((food == 0 || water == 0) && life > 0){
                die();
            }
            if((food < 25 || water < 50) && life > 0){
                life--;
            }
            if((food > 40 && water > 70) && life < 100){
                life += 10;
            }
            if(food <= 20 && Cow.getNumCows() > 0 && Pig.getNumPigs() > 0){
                eat();
            }
            if(water <= 45){
                drink();
            }
            if( ((int)(Math.random() * 40)) + age >= 100){
                life = 0;
                die();
            }
            move();
            if(x >= 1200 || y >= 960 || y <= 0 || x <= 0){
                die();
            }
            if(life <= 50){
                //System.out.println(life);
            }
        }
    }
    public void die(){
        alive = false;
    }
            
    public void eat(){
        Cow.eaten();
        Pig.eaten();
        food += (int)(Math.random() * 30) + 25;
        if(food > 100){
            food = 100;
        }
    }
    public void drink(){
        water += (int)(Math.random() * 50) + 50;
        if(water > 100){
            water = 100;
        }
    }
    public abstract void gainInt();
    public abstract void gainStr();
    public abstract void gainStam();

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }

    public int getFood() {
        return food;
    }

    public void setFood(int food) {
        this.food = food;
    }

    public int getWater() {
        return water;
    }

    public void setWater(int water) {
        this.water = water;
    }

    public double getAge() {
        return age;
    }

    public void setAge(double age) {
        this.age = age;
    }

    public int getIntelligence() {
        return intelligence;
    }

    public void setIntelligence(int intelligence) {
        this.intelligence = intelligence;
    }

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public int getStamina() {
        return stamina;
    }

    public void setStamina(int stamina) {
        this.stamina = stamina;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
    
    
}
