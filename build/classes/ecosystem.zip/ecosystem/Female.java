/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecosystem;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author 807514
 */
public class Female extends Human{
    private ImageIcon ii;
    private Image img;
    
    public Female(){
        super();
        gender = "Female";
        this.ii = new ImageIcon(getClass().getResource("/images/Female.png"));
        this.img = ii.getImage();
    }
    @Override
    public void draw(Graphics g){
        g.drawImage(img, x, y, 25, 25, null);
    }
    @Override
    public void gainInt(){
        intelligence += 1;
    }
    @Override
    public void gainStr(){
        strength += 1;
    }
    @Override
    public void gainStam(){
        stamina += 1;
    }
}
